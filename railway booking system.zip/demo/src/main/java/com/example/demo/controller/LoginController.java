package com.example.demo.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.BookedTickets;
import com.example.demo.model.StationTo;
import com.example.demo.model.Train;
import com.example.demo.model.User;
import com.example.demo.repository.BookedTicketsRepository;
import com.example.demo.repository.TrainRepository;
import com.example.demo.repository.UserRepository;

@Controller
public class LoginController {

	private static Map<String, String> userToPasswordMap = new HashMap<String, String>();
	
	@Autowired
	TrainRepository trainRepository;
	@Autowired
	BookedTicketsRepository repo;
	@Autowired
	UserRepository userRepo;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String loginPahomege(HttpServletRequest request) {
		if (request.getSession().getAttribute("isLoggedInUser") != null
				&& request.getSession().getAttribute("isLoggedInUser").equals("true"))
			return "welcome";
			return "login";
	}
	

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginPage(HttpServletRequest request) {
		if (request.getSession().getAttribute("isLoggedInUser") != null
				&& request.getSession().getAttribute("isLoggedInUser").equals("true"))
			return "welcome";
		return "login";
	}
	
	@RequestMapping(value = "/confirm-booking", method = RequestMethod.POST)
	public  String confirm(HttpServletRequest request,@RequestBody BookedTickets data){
		
		//request.getSession().getAttribute(null);
		
		User user=(User) request.getSession().getAttribute("user");
		BookedTickets bookedtk=(BookedTickets) request.getSession().getAttribute("aa");
		String userName=user.getEmail();
		String bogiclass=bookedtk.getBogiClass();
		
		data.setUname(userName);
		data.setBogiClass(bogiclass);
		data.setDoj(bookedtk.getDoj());
		data.setFstation(bookedtk.getFstation());
		data.setToStation(bookedtk.getToStation());
		data.setStatus("Confirmed");
		
		repo.save(data);
		
		
		return "confirm";
		
	}
	
	@RequestMapping(value = "/checkAvailibility", method = RequestMethod.POST)
	public  ModelAndView checkAvailibility(HttpServletRequest request,@RequestBody BookedTickets data){
		
		/*
		 * String from=fstation;//request.getParameter("fstation"); String
		 * to=request.getParameter("toStation"); String
		 * level=request.getParameter("bogiClass");
		 */
		ModelAndView modelAndView= new ModelAndView("trainlist");
		List<Train> trains=trainRepository.findTrainByDestAndSrc(data.getToStation(), data.getFstation());
		System.out.println(trains);
		request.getSession().setAttribute("aa", data);
		
		List<Train> list= new  ArrayList<>();
		if(trains.size()==0) {
		Train t= new Train();
		t.setTrain_name("sanghaMitra");
		t.setTrain_number(11234);
		t.setOrigin("Bangalore");
		t.setDestination("Patna");
		list.add(t);
		modelAndView.addObject("availableTrainList",list);
		}else {
			modelAndView.addObject("availableTrainList",trains);
			request.getSession().setAttribute("trains", trains);
		}
		
		//System.out.println(from+"================================================");
		System.out.println(data.getToStation()+"================================================");
		System.out.println(data.getFstation()+"================================================");
		/*
		 * data : JSON.stringify(data), dataType : 'json', timeout : 100000,
		 */
		return modelAndView;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView welcome(HttpServletRequest request, ModelMap model, @RequestParam String email, String password) {

		ModelAndView mav = new ModelAndView();

		User user=new User();
        mav.addObject("user", user);
        mav.setViewName("login");
		
		if (!userToPasswordMap.containsKey(email)) {
			model.put("errorMsg", "Not A Valid User");
			return mav;
		}
		if (!userToPasswordMap.get(email).equals(password)) {
			model.put("errorMsg", "Wrong Password");
			return mav;
		}

		request.getSession().setAttribute("isLoggedInUser", "true");
		user=(User) request.getSession().getAttribute("user");
		String userName=user.getName();
		mav.addObject("userName", userName);
		mav.addObject("userMessage", "Welcome To Train Ticket Booking System");
		mav.setViewName("revervation");
		StationTo stationTo= new StationTo();
		List<String> stationList= new ArrayList<>();
		stationList.add("PNBE");
		stationList.add("SBC");
		stationList.add("Test1");
		stationList.add("Test2");
		stationList.add("Test3");
		stationList.add("Test4");
		stationList.add("Test5");
		stationList.add("Test6");
		stationTo.setStationCode(stationList);
	    mav.addObject("stationDetails", stationTo);
		return mav;
	}

	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public String register(HttpServletRequest request,ModelMap model) {
		
		if (request.getSession().getAttribute("isLoggedInUser") != null
				&& request.getSession().getAttribute("isLoggedInUser").equals("true"))
			return "welcome";
		
		
		model.addAttribute("user", new User());
		return "registration";

	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String registerProcess(ModelMap model, @ModelAttribute("user") User user,HttpServletRequest request) {

		if (user == null) {
			model.put("errMsg", "Please Provide Valid Cred");
			return "register";
		}
		if (user.getName() == null || user.getName().equals("")) {
			model.put("errMsg", "Please Provide Name");
			return "register";
		}
		if (user.getPassword() == null || user.getPassword().equals("")) {
			model.put("errMsg", "Please Provide Password");
			return "register";
		}
		request.getSession().setAttribute("user",user);
		userRepo.save(user);
		
		this.userToPasswordMap.put(user.getEmail(), user.getPassword());
		model.addAttribute("user", user);
		
		request.getSession().setAttribute("user", user);
		return "login";

	}
	
	@RequestMapping(value = "/booking-history", method = RequestMethod.GET)
	public ModelAndView displayBooking(HttpServletRequest request) {
		ModelAndView mv= new ModelAndView("bookingHistory");
		List<BookedTickets> bookingList=repo.findAll();
		User user=(User) request.getSession().getAttribute("user");
		List<BookedTickets> finalList=new ArrayList<BookedTickets>();
		for(BookedTickets bt:bookingList) {
			if(bt.getUname().equalsIgnoreCase(user.getEmail())) {
				finalList.add(bt);
			}
		}
		mv.addObject("bookingList", finalList);
		
		return mv;
		
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request) {
		
		request.getSession().setAttribute("isLoggedInUser","false");
		return "login";

	}
}
