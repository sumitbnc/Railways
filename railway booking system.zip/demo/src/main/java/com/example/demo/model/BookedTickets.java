package com.example.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BookedTickets {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String bookingId;

	@Column
	private String uname;
	@Column
	private int tnumber;
	@Column(name="class")
	private String bogiClass;
	@Column
	private Date doj;
	@Column
	private Date dob;
	@Column
	private String fstation;
	@Column
	private String toStation;
	@Column
	private String name;
	@Column
	private int age;
	@Column
	private String sex;
	@Column
	private String status;
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getTnumber() {
		return tnumber;
	}
	public void setTnumber(int tnumber) {
		this.tnumber = tnumber;
	}
	public String getBogiClass() {
		return bogiClass;
	}
	public void setBogiClass(String bogiClass) {
		this.bogiClass = bogiClass;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getFstation() {
		return fstation;
	}
	public void setFstation(String fstation) {
		this.fstation = fstation;
	}
	public String getToStation() {
		return toStation;
	}
	public void setToStation(String toStation) {
		this.toStation = toStation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
					
}
