package com.example.demo.model;

public class SeatAvailability {

}
