package com.example.demo.model;

import java.util.List;

public class StationTo {

	public List<String> stationCode;

	public List<String> getStationCode() {
		return stationCode;
	}

	public void setStationCode(List<String> stationCode) {
		this.stationCode = stationCode;
	}
	
	

}
