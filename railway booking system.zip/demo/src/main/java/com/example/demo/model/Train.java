package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "trainlist")
public class Train {

	@Column(name = "trainnumber")
	@Id
	public int train_number;
	@Column
	public String name;
	@Column
	public String origin;
	@Column
	public String destination;
	@Column
	public String arrival;
	@Column
	public String departure;
	@Column
	public String Mon;
	@Column
	public String Tue;
	@Column
	public String Wed;
	@Column
	public String Thu;
	@Column
	public String Fri;
	@Column
	public String Sat;
	@Column
	public String sun;
	@Column
	public int A1;
	@Column
	public int A2;
	@Column
	public int A3;
	@Column
	public int SL;
	@Column
	public int General;
	@Column
	public int Ladies;
	@Column
	public int Tatkal;

	public int getTrain_number() {
		return train_number;
	}

	public void setTrain_number(int train_number) {
		this.train_number = train_number;
	}

	public String getTrain_name() {
		return name;
	}

	public void setTrain_name(String train_name) {
		this.name = train_name;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getArrival() {
		return arrival;
	}

	public void setArrival(String arrival) {
		this.arrival = arrival;
	}

	public String getDepatrture() {
		return departure;
	}

	public void setDepatrture(String depatrture) {
		this.departure = depatrture;
	}

	public String getMon() {
		return Mon;
	}

	public void setMon(String mon) {
		Mon = mon;
	}

	public String getTue() {
		return Tue;
	}

	public void setTue(String tue) {
		Tue = tue;
	}

	public String getWed() {
		return Wed;
	}

	public void setWed(String wed) {
		Wed = wed;
	}

	public String getThur() {
		return Thu;
	}

	public void setThur(String thur) {
		Thu = thur;
	}

	public String getFri() {
		return Fri;
	}

	public void setFri(String fri) {
		this.Fri = fri;
	}

	public String getSat() {
		return Sat;
	}

	public void setSat(String sat) {
		Sat = sat;
	}

	public String getSun() {
		return sun;
	}

	public void setSun(String sun) {
		this.sun = sun;
	}

	public int getA1() {
		return A1;
	}

	public void setA1(int a1) {
		A1 = a1;
	}

	public int getA2() {
		return A2;
	}

	public void setA2(int a2) {
		A2 = a2;
	}

	public int getA3() {
		return A3;
	}

	public void setA3(int a3) {
		A3 = a3;
	}

	public int getSL() {
		return SL;
	}

	public void setSL(int sL) {
		SL = sL;
	}

	public int getGeneral() {
		return General;
	}

	public void setGeneral(int general) {
		General = general;
	}

	public int getLadies() {
		return Ladies;
	}

	public void setLadies(int ladies) {
		Ladies = ladies;
	}

	public int getTatkal() {
		return Tatkal;
	}

	public void setTatkal(int tatkal) {
		Tatkal = tatkal;
	}

}
