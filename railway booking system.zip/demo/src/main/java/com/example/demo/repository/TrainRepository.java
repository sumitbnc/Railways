package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Train;


public interface TrainRepository extends JpaRepository<Train,Integer>
{
	
	@Query("SELECT u FROM Train u WHERE u.destination = ?1 and u.origin = ?2")
	List<Train> findTrainByDestAndSrc(String destination, String origin);

}
