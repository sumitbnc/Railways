insert into trainlist(trainnumber,name,origin,destination,Arrival,Departure,MON,TUE,WED,THU,FRI,SAT,SUN,A1,A2,A3,SL,General,Ladies,Tatkal) VALUES 
(12008,'SHATABDI EXP','Mumbai','Bangaluru','12:20AM','10:30PM','yes','yes','yes','yes','yes','yes','yes',20,21,23,21,21,30,20);

insert into trainlist(trainnumber,name,origin,destination,Arrival,Departure,MON,TUE,WED,THU,FRI,SAT,SUN,A1,A2,A3,SL,General,Ladies,Tatkal) VALUES 
(65765,'GAREEB Rath EXP','Patna','Delhi','12:20AM','10:30PM','yes','yes','yes','yes','yes','yes','yes',20,21,23,21,21,30,20);

insert into trainlist(trainnumber,name,origin,destination,Arrival,Departure,MON,TUE,WED,THU,FRI,SAT,SUN,A1,A2,A3,SL,General,Ladies,Tatkal) VALUES 
(12898,'Gorakhpur EXP','Gorakhpur','Chennai','12:20AM','10:30PM','yes','yes','yes','yes','yes','yes','yes',20,21,23,21,21,30,20);

insert into trainlist(trainnumber,name,origin,destination,Arrival,Departure,MON,TUE,WED,THU,FRI,SAT,SUN,A1,A2,A3,SL,General,Ladies,Tatkal) VALUES 
(12998,'Rajdhani EXP','Howrah','Hydrabad','12:20AM','10:30PM','yes','yes','yes','yes','yes','yes','yes',20,21,23,21,21,30,20);

insert into trainlist(trainnumber,name,origin,destination,Arrival,Departure,MON,TUE,WED,THU,FRI,SAT,SUN,A1,A2,A3,SL,General,Ladies,Tatkal) VALUES 
(120308,'Hanshani EXP','Mumbai','Bangaluru','12:20AM','10:30PM','yes','yes','yes','yes','yes','yes','yes',20,21,23,21,21,30,20);




insert into booking (uname,Tnumber,class,doj,DOB,fromstn,tostn,Name,Age,sex,Status)VALUES ('Richa',15009,'B1','2021-12-08','2021-12-09',
'Bangalore','Chennai','Richa',20,'female','confirmed');

insert into booking (uname,Tnumber,class,doj,DOB,fromstn,tostn,Name,Age,sex,Status)VALUES ('Javeeria',16009,'A1','2021-11-09','2021-11-10',
'Bangalore','Chennai','Richa',20,'female','confirmed');

insert into booking (uname,Tnumber,class,doj,DOB,fromstn,tostn,Name,Age,sex,Status)VALUES ('Rita',15109,'SLEEPER','2021-09-28','2021-09-29',
'Bangalore','Chennai','Richa',20,'female','confirmed');

insert into booking (uname,Tnumber,class,doj,DOB,fromstn,tostn,Name,Age,sex,Status)VALUES ('Ramu',15239,'A1','2021-08-06','2021-08-07',
'Bangalore','Chennai','Richa',20,'male','confirmed');

insert into booking (uname,Tnumber,class,doj,DOB,fromstn,tostn,Name,Age,sex,Status)VALUES ('Shyam',14002,'A1','2021-04-08','2021-04-09',
'Bangalore','Chennai','Richa',20,'male','confirmed');


insert into seats_availability(train_number,train_name,doj,A1,A2,A3,SL,General,Ladies ,TATKAL) values(15009,'Goreeb Rath Exp','2020-12-08',6,6,6,6,6,6,2);

insert into seats_availability(train_number,train_name,doj,A1,A2,A3,SL,General,Ladies ,TATKAL) values(16009,'Gorakhpur Exp','2020-11-09',7,8,8,7,6,6,5);

insert into seats_availability(train_number,train_name,doj,A1,A2,A3,SL,General,Ladies ,TATKAL) values(15109,'Rajdhani Exp','2020-09-28',5,6,6,6,6,6,2);







