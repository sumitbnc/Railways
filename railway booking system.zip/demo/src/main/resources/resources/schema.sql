CREATE TABLE booking
(uname VARCHAR(128) NOT NULL,
tnumber int(11) NOT NULL,
class VARCHAR(128) NOT NULL,
doj date NOT NULL,
DOB date NOT NULL,
fromstn VARCHAR(128) NOT NULL,
tostn VARCHAR(128) NOT NULL,
name VARCHAR(128) NOT NULL,
age int(12) NOT NULL,
sex VARCHAR(128) NOT NULL,
Status VARCHAR(128) NOT NULL
);
CREATE TABLE trainlist
(trainnumber int(12) primary key,
name VARCHAR(30) NOT NULL,
origin VARCHAR(128) NOT NULL,
destination VARCHAR(110) NOT NULL,
arrival VARCHAR(128) NOT NULL,
departure VARCHAR(128) NOT NULL,
Mon VARCHAR(12) NOT NULL,
Tue VARCHAR(12) NOT NULL,
Wed VARCHAR(12) NOT NULL,
Thu VARCHAR(12) NOT NULL,
Fri VARCHAR(12) NOT NULL,
Sat VARCHAR(12) NOT NULL,
Sun VARCHAR(12) NOT NULL,
A1 int(12) NOT NULL,
A2 int(12) NOT NULL,
A3 int(12) NOT NULL,
SL int(12) NOT NULL,
General int(12) NOT NULL,
Ladies int(12) NOT NULL,
Tatkal int(12) NOT NULL
);
CREATE TABLE seats_availability
(train_number int(12) NOT NULL,
train_name VARCHAR(122) NOT NULL,
doj date NOT NULL,
A1 int(10) NOT NULL,
A2 int(10) NOT NULL,
A3 int(10) NOT NULL,
SL int(10) NOT NULL,
General int(10) NOT NULL,
Ladies int(10) NOT NULL,
TATKAL int(10) NOT NULL
);
CREATE TABLE users
(user_id int NOT NULL,
name VARCHAR(20) NOT NULL,
email VARCHAR(20) NOT NULL,
password VARCHAR(20) NOT NULL,
gender VARCHAR(10),
phone VARCHAR(10)
);


